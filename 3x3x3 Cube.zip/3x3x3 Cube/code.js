var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["645cad50-c2fe-4be9-a43b-4a8e1d0c977b","fd9602af-702a-4abd-83f9-b82ffcc45a68","778fd6a7-75cc-4208-b43e-b0d345fa5826","7b6b2fb9-6105-4057-98c0-df86639c1a6b","b50f291f-122b-4088-b4eb-2c11d7d07fd0","d7a244fc-88be-4833-b5ce-01701af9492a","958450fd-511b-4332-802d-865981749765","cb394259-e0cf-430c-9675-2651041117c8","2740abd3-f4e8-4590-871d-06f5d056dc76","dcb7a4d0-0655-49b5-ac0a-11ee5e62f71a","2ccc30fc-efb0-453b-b66d-093519238d30","6b5a0ec4-7f37-4808-bcd8-b330aacffc7d","a4e691bb-51f6-4332-89a0-cc224d9c491e","11a6a1e3-5c9d-469e-83e0-d1002757313a","2da7da14-fb63-40e3-bd1b-c5afec289a2d","33884c16-395e-4786-9fcc-0dfd053d64c0"],"propsByKey":{"645cad50-c2fe-4be9-a43b-4a8e1d0c977b":{"name":"F","sourceUrl":null,"frameSize":{"x":30,"y":45},"frameCount":6,"looping":true,"frameDelay":12,"version":"AYVopILhZJmygimyDFgKuOzmbnTxnsVT","loadedFromSource":true,"saved":true,"sourceSize":{"x":90,"y":90},"rootRelativePath":"assets/645cad50-c2fe-4be9-a43b-4a8e1d0c977b.png"},"fd9602af-702a-4abd-83f9-b82ffcc45a68":{"name":"R","sourceUrl":null,"frameSize":{"x":30,"y":45},"frameCount":6,"looping":true,"frameDelay":12,"version":"rFGwZo.cwg1Ju8LPiLP1Zcpoik_OjAyi","loadedFromSource":true,"saved":true,"sourceSize":{"x":90,"y":90},"rootRelativePath":"assets/fd9602af-702a-4abd-83f9-b82ffcc45a68.png"},"778fd6a7-75cc-4208-b43e-b0d345fa5826":{"name":"U","sourceUrl":null,"frameSize":{"x":60,"y":29},"frameCount":6,"looping":true,"frameDelay":12,"version":"yliw94pOLM.Vcdjaw1j16GQn6sosPTTv","loadedFromSource":true,"saved":true,"sourceSize":{"x":120,"y":87},"rootRelativePath":"assets/778fd6a7-75cc-4208-b43e-b0d345fa5826.png"},"7b6b2fb9-6105-4057-98c0-df86639c1a6b":{"name":"arrow","sourceUrl":null,"frameSize":{"x":48,"y":48},"frameCount":2,"looping":true,"frameDelay":12,"version":"tNSzfKISZ6tpcZdbmLwkGQ.3mvng1yoM","loadedFromSource":true,"saved":true,"sourceSize":{"x":48,"y":96},"rootRelativePath":"assets/7b6b2fb9-6105-4057-98c0-df86639c1a6b.png"},"b50f291f-122b-4088-b4eb-2c11d7d07fd0":{"name":"x","sourceUrl":null,"frameSize":{"x":33,"y":33},"frameCount":2,"looping":true,"frameDelay":12,"version":"nfLfA0m31QTzd5_D0jEHzY.EMLUs2KW6","loadedFromSource":true,"saved":true,"sourceSize":{"x":33,"y":66},"rootRelativePath":"assets/b50f291f-122b-4088-b4eb-2c11d7d07fd0.png"},"d7a244fc-88be-4833-b5ce-01701af9492a":{"name":"y","sourceUrl":null,"frameSize":{"x":33,"y":33},"frameCount":2,"looping":true,"frameDelay":12,"version":"1an9.1uv35zGBwrw8WGPWnW7WUX66cUx","loadedFromSource":true,"saved":true,"sourceSize":{"x":33,"y":66},"rootRelativePath":"assets/d7a244fc-88be-4833-b5ce-01701af9492a.png"},"958450fd-511b-4332-802d-865981749765":{"name":"z","sourceUrl":null,"frameSize":{"x":33,"y":33},"frameCount":2,"looping":true,"frameDelay":12,"version":"Tio.Ibz7IC6tkr1NsAFG0xT7mHQmGDxP","loadedFromSource":true,"saved":true,"sourceSize":{"x":33,"y":66},"rootRelativePath":"assets/958450fd-511b-4332-802d-865981749765.png"},"cb394259-e0cf-430c-9675-2651041117c8":{"name":"x'","sourceUrl":null,"frameSize":{"x":43,"y":48},"frameCount":2,"looping":true,"frameDelay":12,"version":"DalAMfIxtzDj8.itqrWRCo8oqOZVLwgK","loadedFromSource":true,"saved":true,"sourceSize":{"x":43,"y":96},"rootRelativePath":"assets/cb394259-e0cf-430c-9675-2651041117c8.png"},"2740abd3-f4e8-4590-871d-06f5d056dc76":{"name":"y'","sourceUrl":null,"frameSize":{"x":43,"y":48},"frameCount":2,"looping":true,"frameDelay":12,"version":"cIUVVMnoZ8GAfBzCobxAUuvncxbAU6Yx","loadedFromSource":true,"saved":true,"sourceSize":{"x":43,"y":96},"rootRelativePath":"assets/2740abd3-f4e8-4590-871d-06f5d056dc76.png"},"dcb7a4d0-0655-49b5-ac0a-11ee5e62f71a":{"name":"z'","sourceUrl":null,"frameSize":{"x":43,"y":48},"frameCount":2,"looping":true,"frameDelay":12,"version":"a5mJiYVgHoOxIccNjHjLt3.dxKUnHqw0","loadedFromSource":true,"saved":true,"sourceSize":{"x":43,"y":96},"rootRelativePath":"assets/dcb7a4d0-0655-49b5-ac0a-11ee5e62f71a.png"},"2ccc30fc-efb0-453b-b66d-093519238d30":{"name":"Fmove","sourceUrl":null,"frameSize":{"x":33,"y":48},"frameCount":2,"looping":true,"frameDelay":12,"version":"gxNQ1BWjAZSB0DatqO08.g_BbeLY0jTO","loadedFromSource":true,"saved":true,"sourceSize":{"x":66,"y":48},"rootRelativePath":"assets/2ccc30fc-efb0-453b-b66d-093519238d30.png"},"6b5a0ec4-7f37-4808-bcd8-b330aacffc7d":{"name":"F'move","sourceUrl":null,"frameSize":{"x":43,"y":48},"frameCount":2,"looping":true,"frameDelay":12,"version":"0.rqFt84gjSx1nVGLvqH3lFwq2KQZsdu","loadedFromSource":true,"saved":true,"sourceSize":{"x":43,"y":96},"rootRelativePath":"assets/6b5a0ec4-7f37-4808-bcd8-b330aacffc7d.png"},"a4e691bb-51f6-4332-89a0-cc224d9c491e":{"name":"Bmove","sourceUrl":null,"frameSize":{"x":33,"y":48},"frameCount":2,"looping":true,"frameDelay":12,"version":"4okXUkiuuL656zdaRjk3HNq9p0aZAYs0","loadedFromSource":true,"saved":true,"sourceSize":{"x":66,"y":48},"rootRelativePath":"assets/a4e691bb-51f6-4332-89a0-cc224d9c491e.png"},"11a6a1e3-5c9d-469e-83e0-d1002757313a":{"name":"B'move","sourceUrl":null,"frameSize":{"x":43,"y":48},"frameCount":2,"looping":true,"frameDelay":12,"version":"ZhwsI73WMD1.ipofC.NVy4x9H06Exm49","loadedFromSource":true,"saved":true,"sourceSize":{"x":43,"y":96},"rootRelativePath":"assets/11a6a1e3-5c9d-469e-83e0-d1002757313a.png"},"2da7da14-fb63-40e3-bd1b-c5afec289a2d":{"name":"Smove","sourceUrl":null,"frameSize":{"x":33,"y":48},"frameCount":2,"looping":true,"frameDelay":12,"version":"wvwWU9b13ycbAOxFQKCDQM5uVMHW8Y8F","loadedFromSource":true,"saved":true,"sourceSize":{"x":66,"y":48},"rootRelativePath":"assets/2da7da14-fb63-40e3-bd1b-c5afec289a2d.png"},"33884c16-395e-4786-9fcc-0dfd053d64c0":{"name":"S'move","sourceUrl":null,"frameSize":{"x":43,"y":48},"frameCount":2,"looping":true,"frameDelay":12,"version":"5xCGngSEkg9zGfe6h1GRS_Q8z96ZumkW","loadedFromSource":true,"saved":true,"sourceSize":{"x":43,"y":96},"rootRelativePath":"assets/33884c16-395e-4786-9fcc-0dfd053d64c0.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var getRow = function(side,a) {
  return [side[a*3], side[a*3+1], side[a*3+2]];
};
var getCol = function(side,a) {
  return [side[0+a], side[3+a], side[6+a]];
};

function storeRow(side, a, val) {
  side[a*3] = val[0];
  side[a*3+1] = val[1];
  side[a*3+2] = val[2];
  return side;
}

function storeCol(side, a, val) {
  side[a] = val[0];
  side[a+3] = val[1];
  side[a+6] = val[2];
  return side;
}

var sideSurround = function() {
  var x = [];
  
  for (var i = 0; i < 4; i++) {
    if (!arguments[i+8]) {
      x.push(getRow(arguments[i].side,arguments[i+4])[0]);
      x.push(getRow(arguments[i].side,arguments[i+4])[1]);
      x.push(getRow(arguments[i].side,arguments[i+4])[2]);
    } else {
      x.push(getCol(arguments[i].side,arguments[i+4])[0]);
      x.push(getCol(arguments[i].side,arguments[i+4])[1]);
      x.push(getCol(arguments[i].side,arguments[i+4])[2]);
    }
  }
  
  return x;
};

Array.prototype.fill = function(a,b) {
  for (var i = 0; i<b;i++) {
    this.push(a);
  }
  return this;
};

function side(color) {
  this.side = ([]).fill(color,9);
  this.color = color;
  this.reset = function() {
    this.side = ([]).fill(this.color,9);
  };
}

var colors = [rgb(0,255,0),rgb(0,0,255),rgb(255,128,0),rgb(255,0,0),rgb(255,255,255),rgb(255,255,0)];

var F = new side(0);
var B = new side(1);
var L = new side(2);
var R = new side(3);
var U = new side(4);
var D = new side(5);

var backGround = createSprite(275,275,150,150);
backGround.shapeColor = "black";

var Ftl2 = createSprite(225,225,48,48);
var Ftm2 = createSprite(275,225,48,48);
var Ftr2 = createSprite(325,225,48,48);
var Fml2 = createSprite(225,275,48,48);
var Fmm2 = createSprite(275,275,48,48);
var Fmr2 = createSprite(325,275,48,48);
var Fbl2 = createSprite(225,325,48,48);
var Fbm2 = createSprite(275,325,48,48);
var Fbr2 = createSprite(325,325,48,48);

var Uprime = createSprite(375,225);
Uprime.setAnimation("arrow");
Uprime.rotation = 90;
Uprime.pause();
var Unorm = createSprite(175,225);
Unorm.setAnimation("arrow");
Unorm.rotation = -90;
Unorm.pause();
var Eprime = createSprite(375,275);
Eprime.setAnimation("arrow");
Eprime.rotation = 90;
Eprime.pause();
var Enorm = createSprite(175,275);
Enorm.setAnimation("arrow");
Enorm.rotation = -90;
Enorm.pause();
var Dnorm = createSprite(375,325);
Dnorm.setAnimation("arrow");
Dnorm.rotation = 90;
Dnorm.pause();
var Dprime = createSprite(175,325);
Dprime.setAnimation("arrow");
Dprime.rotation = -90;
Dprime.pause();

var Rprime = createSprite(325,375);
Rprime.setAnimation("arrow");
Rprime.rotation = 180;
Rprime.pause();
var Rnorm = createSprite(325,175);
Rnorm.setAnimation("arrow");
Rnorm.rotation = 0;
Rnorm.pause();
var Mprime = createSprite(275,375);
Mprime.setAnimation("arrow");
Mprime.rotation = 180;
Mprime.pause();
var Mnorm = createSprite(275,175);
Mnorm.setAnimation("arrow");
Mnorm.rotation = 0;
Mnorm.pause();
var Lnorm = createSprite(225,375);
Lnorm.setAnimation("arrow");
Lnorm.rotation = 180;
Lnorm.pause();
var Lprime = createSprite(225,175);
Lprime.setAnimation("arrow");
Lprime.rotation = 0;
Lprime.pause();

var Fnorm = createSprite(325,125);
Fnorm.setAnimation("Fmove");
Fnorm.pause();
var Fprime = createSprite(225,125);
Fprime.setAnimation("F'move");
Fprime.pause();
var Snorm = createSprite(325,75);
Snorm.setAnimation("Smove");
Snorm.pause();
var Sprime = createSprite(225,75);
Sprime.setAnimation("S'move");
Sprime.pause();
var Bnorm = createSprite(225,25);
Bnorm.setAnimation("Bmove");
Bnorm.pause();
var Bprime = createSprite(325,25);
Bprime.setAnimation("B'move");
Bprime.pause();


var xnorm = createSprite(25.5,232.5);
xnorm.setAnimation("x");
xnorm.pause();
var xprime = createSprite(75.5,225);
xprime.setAnimation("x'");
xprime.pause();
var ynorm = createSprite(25.5,282.5);
ynorm.setAnimation("y");
ynorm.pause();
var yprime = createSprite(75.5,275);
yprime.setAnimation("y'");
yprime.pause();
var znorm = createSprite(75.5,332.5);
znorm.setAnimation("z");
znorm.pause();
var zprime = createSprite(25.5,325);
zprime.setAnimation("z'");
zprime.pause();

var Utl = createSprite(90,14.5);
Utl.setAnimation("U");
Utl.pause();
var Utm = createSprite(120,29.5);
Utm.setAnimation("U");
Utm.pause();
var Utr = createSprite(150,44.5);
Utr.setAnimation("U");
Utr.pause();
var Uml = createSprite(60,29.5);
Uml.setAnimation("U");
Uml.pause();
var Umm = createSprite(90,44.5);
Umm.setAnimation("U");
Umm.pause();
var Umr = createSprite(120,59.5);
Umr.setAnimation("U");
Umr.pause();
var Ubl = createSprite(30,44.5);
Ubl.setAnimation("U");
Ubl.pause();
var Ubm = createSprite(60,59.5);
Ubm.setAnimation("U");
Ubm.pause();
var Ubr = createSprite(90,74.5);
Ubr.setAnimation("U");
Ubr.pause();

var Ftl = createSprite(15,67.5);
Ftl.setAnimation("F");
Ftl.pause();
var Ftm = createSprite(45,82.5);
Ftm.setAnimation("F");
Ftm.pause();
var Ftr = createSprite(75,97.5);
Ftr.setAnimation("F");
Ftr.pause();
var Fml = createSprite(15,98.5);
Fml.setAnimation("F");
Fml.pause();
var Fmm = createSprite(45,113.5);
Fmm.setAnimation("F");
Fmm.pause();
var Fmr = createSprite(75,128.5);
Fmr.setAnimation("F");
Fmr.pause();
var Fbl = createSprite(15,129.5);
Fbl.setAnimation("F");
Fbl.pause();
var Fbm = createSprite(45,144.5);
Fbm.setAnimation("F");
Fbm.pause();
var Fbr = createSprite(75,159.5);
Fbr.setAnimation("F");
Fbr.pause();

var Rtl = createSprite(105,97.5);
Rtl.setAnimation("R");
Rtl.pause();
var Rtm = createSprite(135,82.5);
Rtm.setAnimation("R");
Rtm.pause();
var Rtr = createSprite(165,67.5);
Rtr.setAnimation("R");
Rtr.pause();
var Rml = createSprite(105,128.5);
Rml.setAnimation("R");
Rml.pause();
var Rmm = createSprite(135,113.5);
Rmm.setAnimation("R");
Rmm.pause();
var Rmr = createSprite(165,98.5);
Rmr.setAnimation("R");
Rmr.pause();
var Rbl = createSprite(105,159.5);
Rbl.setAnimation("R");
Rbl.pause();
var Rbm = createSprite(135,144.5);
Rbm.setAnimation("R");
Rbm.pause();
var Rbr = createSprite(165,129.5);
Rbr.setAnimation("R");
Rbr.pause();

drawSide();


/*
 0  1  2        9  A  B
B       3      8       0
A       4  =>  7       1    clockwise rotation            9,10,11,0,1,2,3,4,5,6,7,8
9       5      6       2
 8  7  6        5  4  3
 
 0  1  2        3  4  5
B       3      2       6
A       4  =>  1       7    counterclockwise rotation     3,4,5,6,7,8,9,10,11,0,1,2
9       5      0       8
 9  7  6        B  A  9
*/

function turnSide(side,dir) {
  var buffer, buffer2, buffer3, buffer4, buffer5;
  if (dir==="clockwise") {
    buffer = [
      6, 3, 0,
      7, 4, 1,
      8, 5, 2
    ];
    buffer3 = [
      9,10,11,0,1,2,3,4,5,6,7,8
    ];
  } else if (dir==="counterclockwise") {
    buffer = [
      2, 5, 8,
      1, 4, 7,
      0, 3, 6
    ];
    buffer3 = [
      3,4,5,6,7,8,9,10,11,0,1,2
    ];
  } else {
    return;
  }
  for (var i = 0;i<9; i++) {
    buffer[i]=side.side[buffer[i]];
  }
  if (side === F) {
    buffer2 = sideSurround(L,U,R,D,2,2,0,0,1,0,1,0);
    buffer4 = ["L","U","R","D",2,2,0,0,1,0,1,0];
    buffer5 = "F";
  } else if (side === B) {
    buffer2 = sideSurround(L,U,R,D,0,0,2,2,1,0,1,0);
    buffer4 = ["L","U","R","D",0,0,2,2,1,0,1,0];
    buffer5 = "B";
  } else if (side === R) {
    buffer2 = sideSurround(F,U,B,D,2,2,0,0,1,1,1,1);
    buffer4 = ["F","U","B","D",2,2,0,0,1,1,1,1];
    buffer5 = "R";
  } else if (side === L) {
    buffer2 = sideSurround(F,U,B,D,0,0,2,2,1,1,1,1);
    buffer4 = ["F","U","B","D",0,0,2,2,1,1,1,1];
    buffer5 = "L";
  } else if (side === U) {
    buffer2 = sideSurround(L,B,R,F,2,2,0,0,0,0,0,0);
    buffer4 = ["L","B","R","F",2,2,0,0,0,0,0,0];
    buffer5 = "U";
  } else {
    buffer2 = sideSurround(L,B,R,F,0,0,2,2,0,0,0,0);
    buffer4 = ["L","B","R","F",0,0,2,2,0,0,0,0];
    buffer5 = "D";
  }
  for (var i = 0;i<12;i++) {
    buffer3[i]=buffer2[buffer3[i]];
  }
  
  eval(buffer5).side = buffer;
  
  for (var i = 0;i<4; i++) {
    var s = buffer3.slice(3*i,3*i+3);
    
    if (!buffer4[i+8]) {
      eval(buffer4[i]).side = storeRow(eval(buffer4[i]).side,buffer4[i+4],s);
    } else {
      eval(buffer4[i]).side = storeCol(eval(buffer4[i]).side,buffer4[i+4],s);
    }
    /*   Using eval() can be unsecure if you don't know what you're doing.
    if you're a beginner/intermediate programmer, i'd stay away from it.*/
    
  }
}

function middleMove(dir) {   //for M moves
  var buffer = sideSurround(B,D,F,U,1,1,1,1,1,1,1,1);
  var buffer2;
  
  if (dir == "clockwise") {
    buffer2 = [
      9,10,11,0,1,2,3,4,5,6,7,8
    ];
  } else if (dir == "counterclockwise") {
    buffer2 = [
      3,4,5,6,7,8,9,10,11,0,1,2
    ];
  }
  
  for (var i = 0;i<12;i++) {
    buffer2[i]=buffer[buffer2[i]];
  }
  
  B.side = storeCol(B.side,1,buffer2.slice(0,3));
  D.side = storeCol(D.side,1,buffer2.slice(3,6));
  F.side = storeCol(F.side,1,buffer2.slice(6,9));
  U.side = storeCol(U.side,1,buffer2.slice(9,12));
  
}

function edgeMove(dir) {    //for E moves
  var buffer = sideSurround(B,R,F,L,1,1,1,1,0,0,0,0);
  var buffer2;
  
  if (dir == "clockwise") {
    buffer2 = [
      3,4,5,6,7,8,9,10,11,0,1,2
    ];
  } else if (dir == "counterclockwise") {
    buffer2 = [
      9,10,11,0,1,2,3,4,5,6,7,8
    ];
  }
  
  for (var i = 0;i<12;i++) {
    buffer2[i]=buffer[buffer2[i]];
  }
  
  F.side = storeRow(F.side,1,buffer2.slice(0,3));
  L.side = storeRow(L.side,1,buffer2.slice(3,6));
  B.side = storeRow(B.side,1,buffer2.slice(6,9));
  R.side = storeRow(R.side,1,buffer2.slice(9,12));
}

function sideMove(dir) {
  var buffer = sideSurround(L,U,R,D,1,1,1,1,1,0,1,0);
  var buffer2;
  
  if (dir == "clockwise") {
    buffer2 = [
      9,10,11,0,1,2,3,4,5,6,7,8
    ];
  } else if (dir == "counterclockwise") {
    buffer2 = [
      3,4,5,6,7,8,9,10,11,0,1,2
    ];
  }
  
  for (var i = 0;i<12;i++) {
    buffer2[i]=buffer[buffer2[i]];
  }
  
  L.side = storeCol(L.side,1,buffer2.slice(0,3));
  U.side = storeRow(U.side,1,buffer2.slice(3,6));
  R.side = storeCol(R.side,1,buffer2.slice(6,9));
  D.side = storeRow(D.side,1,buffer2.slice(9,12));
}

function xMove(dir) {
  if (dir == "clockwise") {
    middleMove("clockwise");
    turnSide(R,"clockwise");
    turnSide(L,"clockwise");
  } else {
    middleMove("counterclockwise");
    turnSide(R,"counterclockwise");
    turnSide(L,"counterclockwise");
  }
}

function yMove(dir) {
  if (dir == "clockwise") {
    edgeMove("clockwise");
    turnSide(U,"clockwise");
    turnSide(D,"clockwise");
  } else {
    edgeMove("counterclockwise");
    turnSide(U,"counterclockwise");
    turnSide(D,"counterclockwise");
  }
}

function zMove(dir) {
  if (dir == "clockwise") {
    sideMove("clockwise");
    turnSide(F,"clockwise");
    turnSide(B,"clockwise");
  } else {
    sideMove("counterclockwise");
    turnSide(F,"counterclockwise");
    turnSide(B,"counterclockwise");
  }
}


function drawSide() {
  Utl.setFrame(U.side[0]);
  Utm.setFrame(U.side[1]);
  Utr.setFrame(U.side[2]);
  Uml.setFrame(U.side[3]);
  Umm.setFrame(U.side[4]);
  Umr.setFrame(U.side[5]);
  Ubl.setFrame(U.side[6]);
  Ubm.setFrame(U.side[7]);
  Ubr.setFrame(U.side[8]);
  
  Ftl2.shapeColor = colors[F.side[0]];
  Ftm2.shapeColor = colors[F.side[1]];
  Ftr2.shapeColor = colors[F.side[2]];
  Fml2.shapeColor = colors[F.side[3]];
  Fmm2.shapeColor = colors[F.side[4]];
  Fmr2.shapeColor = colors[F.side[5]];
  Fbl2.shapeColor = colors[F.side[6]];
  Fbm2.shapeColor = colors[F.side[7]];
  Fbr2.shapeColor = colors[F.side[8]];
  
  Ftl.setFrame(F.side[0]);
  Ftm.setFrame(F.side[1]);
  Ftr.setFrame(F.side[2]);
  Fml.setFrame(F.side[3]);
  Fmm.setFrame(F.side[4]);
  Fmr.setFrame(F.side[5]);
  Fbl.setFrame(F.side[6]);
  Fbm.setFrame(F.side[7]);
  Fbr.setFrame(F.side[8]);
  
  Rtl.setFrame(R.side[0]);
  Rtm.setFrame(R.side[1]);
  Rtr.setFrame(R.side[2]);
  Rml.setFrame(R.side[3]);
  Rmm.setFrame(R.side[4]);
  Rmr.setFrame(R.side[5]);
  Rbl.setFrame(R.side[6]);
  Rbm.setFrame(R.side[7]);
  Rbr.setFrame(R.side[8]);
  
  drawSprites();
}

function algorithm() {
  var a,b,c, d;
  
  c = false;
  
  for (var i = 0; i < arguments.length; i++) {
    
    b = arguments[i];
    
    if (b.charAt(1) == "'") {
      a = "counterclockwise";
      
      if (b.charAt(0) == "D" || b.charAt(0) == "L" || b.charAt(0) == "B") {
        a = "clockwise";
      }
      
    } else if (b.charAt(1) == 2) {
      a = "clockwise";
      c = true;
    } else {
      a = "clockwise";
      if (b.charAt(0) == "D" || b.charAt(0) == "L" || b.charAt(0) == "B") {
        a = "counterclockwise";
      }
    }
    
    if (b.charAt(0) !== "M" && b.charAt(0) !== "E" && b.charAt(0) !== "S" && b.charAt(0) !== "x" && b.charAt(0) !== "y" && b.charAt(0) !== "z") {
      d = "turnSide(eval(b.charAt(0)),a);";
    } else if (b.charAt(0) == "M") {
      d = "middleMove(a);";
    } else if (b.charAt(0) == "E") {
      d = "edgeMove(a);";
    } else if (b.charAt(0) == "S") {
      d = "sideMove(a)";
    } else if (b.charAt(0) == "x") {
      d = "xMove(a);";
    } else if (b.charAt(0) == "y") {
      d = "yMove(a)";
    } else if (b.charAt(0) == "z") {
      d = "zMove(a)";
    }
    
    if (c) {
      eval(d);
    }
    eval(d);
    
    c = false;
    
  }
  
}

function draw() {
  var currSide;
  
  if (mouseIsOver(Uprime)) {
    Uprime.setFrame(1);
    currSide = "U'";
  } else {
    Uprime.setFrame(0);
  }
  if (mouseIsOver(Unorm)) {
    Unorm.setFrame(1);
    currSide = "U";
  } else {
    Unorm.setFrame(0);
  }
  
  if (mouseIsOver(Eprime)) {
    Eprime.setFrame(1);
    currSide = "E'";
  } else {
    Eprime.setFrame(0);
  }
  if (mouseIsOver(Enorm)) {
    Enorm.setFrame(1);
    currSide = "E";
  } else {
    Enorm.setFrame(0);
  }
  
  if (mouseIsOver(Dprime)) {
    Dprime.setFrame(1);
    currSide = "D'";
  } else {
    Dprime.setFrame(0);
  }
  if (mouseIsOver(Dnorm)) {
    Dnorm.setFrame(1);
    currSide = "D";
  } else {
    Dnorm.setFrame(0);
  }
  
  if (mouseIsOver(Rprime)) {
    Rprime.setFrame(1);
    currSide = "R'";
  } else {
    Rprime.setFrame(0);
  }
  if (mouseIsOver(Rnorm)) {
    Rnorm.setFrame(1);
    currSide = "R";
  } else {
    Rnorm.setFrame(0);
  }
  
  if (mouseIsOver(Mprime)) {
    Mprime.setFrame(1);
    currSide = "M'";
  } else {
    Mprime.setFrame(0);
  }
  if (mouseIsOver(Mnorm)) {
    Mnorm.setFrame(1);
    currSide = "M";
  } else {
    Mnorm.setFrame(0);
  }
  
  if (mouseIsOver(Lprime)) {
    Lprime.setFrame(1);
    currSide = "L'";
  } else {
    Lprime.setFrame(0);
  }
  if (mouseIsOver(Lnorm)) {
    Lnorm.setFrame(1);
    currSide = "L";
  } else {
    Lnorm.setFrame(0);
  }
  
  if (mouseIsOver(Fprime)) {
    Fprime.setFrame(1);
    currSide = "F'";
  } else {
    Fprime.setFrame(0);
  }
  if (mouseIsOver(Fnorm)) {
    Fnorm.setFrame(1);
    currSide = "F";
  } else {
    Fnorm.setFrame(0);
  }
  
  if (mouseIsOver(Sprime)) {
    Sprime.setFrame(1);
    currSide = "S'";
  } else {
    Sprime.setFrame(0);
  }
  if (mouseIsOver(Snorm)) {
    Snorm.setFrame(1);
    currSide = "S";
  } else {
    Snorm.setFrame(0);
  }
  
  if (mouseIsOver(Bprime)) {
    Bprime.setFrame(1);
    currSide = "B'";
  } else {
    Bprime.setFrame(0);
  }
  if (mouseIsOver(Bnorm)) {
    Bnorm.setFrame(1);
    currSide = "B";
  } else {
    Bnorm.setFrame(0);
  }
  
  
  if (mouseIsOver(xnorm)) {
    xnorm.setFrame(1);
    currSide = "x";
  } else {
    xnorm.setFrame(0);
  }
  if (mouseIsOver(xprime)) {
    xprime.setFrame(1);
    currSide = "x'";
  } else {
    xprime.setFrame(0);
  }
  if (mouseIsOver(ynorm)) {
    ynorm.setFrame(1);
    currSide = "y";
  } else {
    ynorm.setFrame(0);
  }
  if (mouseIsOver(yprime)) {
    yprime.setFrame(1);
    currSide = "y'";
  } else {
    yprime.setFrame(0);
  }
  if (mouseIsOver(znorm)) {
    znorm.setFrame(1);
    currSide = "z";
  } else {
    znorm.setFrame(0);
  }
  if (mouseIsOver(zprime)) {
    zprime.setFrame(1);
    currSide = "z'";
  } else {
    zprime.setFrame(0);
  }
  
  if (mouseWentDown("left") && currSide !== undefined) {
    algorithm(currSide);
  }
  
  background("white");
  drawSide();
  
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
